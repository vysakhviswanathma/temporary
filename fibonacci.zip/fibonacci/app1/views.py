

from django.shortcuts import render
from django.template import RequestContext
from django.http import HttpResponse

from app1.models import Fibonacci1
from django.views import View
import time
from django.contrib import messages


def fibonacci(number):
    if number < 2:
        return 1

    else:
        t1 = 1
        t2 = 1

        for i in range(2, number):
            value = t1 + t2
            t1 = t2
            t2 = value

        return t2


class Fibonacci(View):

    def get(self, request):

        number = request.GET.get('number')
        try:
            if number is None:
                return render(request, 'app1/index.html')
            else:

                start_time = time.time()
                number = int(number)
                result = fibonacci(number)
                end_time = time.time() - start_time
                timetaken = str(end_time)[0:3]

                fibonacci_ob = Fibonacci1.objects.create(
                    number=number,
                    result=result,
                    timetaken=timetaken
                    )
                fibonacci_ob.save()

                data = {
                    'number': number,
                    'result': result,
                    'timetaken': timetaken
                    }

                return render(request, 'app1/index.html', data)


        except ValueError:

            return render(request,'app1/error.html')

