

from django.contrib import admin

# Register your models here.
from app1.models import Fibonacci1


admin.site.register(Fibonacci1)